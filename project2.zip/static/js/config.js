// API key
// const API_KEY = "YOUR KEY HERE!";

// API key
const API_KEY = "pk.eyJ1IjoiYW5kZXJzamgiLCJhIjoiY2sxODNlMDBzMDZ6cTNvcDFwZTh0eGJnNyJ9.UOYs4mSt5CSEuifzIxu1tA";
